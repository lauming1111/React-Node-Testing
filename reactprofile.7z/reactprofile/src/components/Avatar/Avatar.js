import React from 'react'
import './index.css'

export const Avatar = (props) => (<img className="avatar" src={props.src} />);