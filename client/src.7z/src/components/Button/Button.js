import React from 'react'
import './index.css'

export const Button = (props) => (<button className="button">{props.children}</button>);