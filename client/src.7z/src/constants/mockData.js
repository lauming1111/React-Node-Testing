export const respondJson =

    fetch("/people", {
        method: 'Get'
    }).then(
        function (u) {
            return u.json();
        }
    ).then(
        function (json) {
            console.log(json);
        }
    )

